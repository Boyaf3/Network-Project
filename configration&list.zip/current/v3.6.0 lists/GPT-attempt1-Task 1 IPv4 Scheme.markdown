### A. Site-Level Subnetting

| Site           | Private Block | Subnet Mask   | Usable Hosts | Notes                                      |
|----------------|---------------|---------------|--------------|--------------------------------------------|
| Manama (HQ)    | 10.1.0.0/16   | 255.255.0.0   | 65,534       | Central services, Internet/NAT at HQ       |
| Riyadh         | 10.2.0.0/16   | 255.255.0.0   | 65,534       | Branch 1; projected to double in 5 yrs     |
| Kuwait         | 10.3.0.0/16   | 255.255.0.0   | 65,534       | Branch 2; projected to double in 5 yrs     |

### B. Department-Level Subnetting (Manama HQ)

| Department         | Current Hosts | Subnet Mask     | Subnet ID     | Usable Hosts | IP Range                |
|--------------------|---------------|-----------------|---------------|--------------|-------------------------|
| Management         | 35            | 255.255.255.192 | 10.1.1.0/26   | 62           | 10.1.1.0 – 10.1.1.63    |
| Administration     | 40            | 255.255.255.192 | 10.1.2.0/26   | 62           | 10.1.2.0 – 10.1.2.63    |
| Marketing          | 45            | 255.255.255.192 | 10.1.3.0/26   | 62           | 10.1.3.0 – 10.1.3.63    |
| Human Resources    | 20            | 255.255.255.224 | 10.1.4.0/27   | 30           | 10.1.4.0 – 10.1.4.31    |
| Finance            | 65            | 255.255.255.128 | 10.1.5.0/25   | 126          | 10.1.5.0 – 10.1.5.127   |
| IT                 | 35            | 255.255.255.192 | 10.1.6.0/26   | 62           | 10.1.6.0 – 10.1.6.63    |
| Loan Services      | 20            | 255.255.255.224 | 10.1.7.0/27   | 30           | 10.1.7.0 – 10.1.7.31    |
| Legal              | 20            | 255.255.255.224 | 10.1.8.0/27   | 30           | 10.1.8.0 – 10.1.8.31    |
| Servers (Web/Email)| 4             | 255.255.255.248 | 10.1.9.0/29   | 6            | 10.1.9.0 – 10.1.9.7     |
| WiFi VLAN          | 280           | 255.255.254.0   | 10.1.10.0/23  | 510          | 10.1.10.0 – 10.1.11.255 |

### C. Department-Level Subnetting (Riyadh Branch)

| Department         | Current→Future | Subnet Mask     | Subnet ID     | Usable Hosts | IP Range                |
|--------------------|----------------|-----------------|---------------|--------------|-------------------------|
| Management         | 10→20          | 255.255.255.224 | 10.2.1.0/27   | 30           | 10.2.1.0 – 10.2.1.31    |
| Administration     | 20→40          | 255.255.255.192 | 10.2.2.0/26   | 62           | 10.2.2.0 – 10.2.2.63    |
| Marketing          | 10→20          | 255.255.255.224 | 10.2.3.0/27   | 30           | 10.2.3.0 – 10.2.3.31    |
| Human Resources    | 8→16           | 255.255.255.224 | 10.2.4.0/27   | 30           | 10.2.4.0 – 10.2.4.31    |
| Finance            | 20→40          | 255.255.255.192 | 10.2.5.0/26   | 62           | 10.2.5.0 – 10.2.5.63    |
| IT                 | 15→30          | 255.255.255.192 | 10.2.6.0/26   | 62           | 10.2.6.0 – 10.2.6.63    |
| Loan Services      | 33→66          | 255.255.255.128 | 10.2.7.0/25   | 126          | 10.2.7.0 – 10.2.7.127   |
| Legal              | 10→20          | 255.255.255.224 | 10.2.8.0/27   | 30           | 10.2.8.0 – 10.2.8.31    |
| Servers (Web/Email)| 4              | 255.255.255.248 | 10.2.9.0/29   | 6            | 10.2.9.0 – 10.2.9.7     |

### D. Department-Level Subnetting (Kuwait Branch)

| Department         | Current→Future | Subnet Mask     | Subnet ID     | Usable Hosts | IP Range                |
|--------------------|----------------|-----------------|---------------|--------------|-------------------------|
| Management         | 10→20          | 255.255.255.224 | 10.3.1.0/27   | 30           | 10.3.1.0 – 10.3.1.31    |
| Administration     | 15→30          | 255.255.255.192 | 10.3.2.0/26   | 62           | 10.3.2.0 – 10.3.2.63    |
| Marketing          | 10→20          | 255.255.255.224 | 10.3.3.0/27   | 30           | 10.3.3.0 – 10.3.3.31    |
| Human Resources    | 8→16           | 255.255.255.224 | 10.3.4.0/27   | 30           | 10.3.4.0 – 10.3.4.31    |
| Finance            | 15→30          | 255.255.255.192 | 10.3.5.0/26   | 62           | 10.3.5.0 – 10.3.5.63    |
| IT                 | 15→30          | 255.255.255.192 | 10.3.6.0/26   | 62           | 10.3.6.0 – 10.3.6.63    |
| Loan Services      | 55→110         | 255.255.255.128 | 10.3.7.0/25   | 126          | 10.3.7.0 – 10.3.7.127   |
| Legal              | 5→10           | 255.255.255.240 | 10.3.8.0/28   | 14           | 10.3.8.0 – 10.3.8.15    |
| Servers (Web/Email)| 4              | 255.255.255.248 | 10.3.9.0/29   | 6            | 10.3.9.0 – 10.3.9.7     |

### E. Router Connections

| Subnet ID       | Subnet Mask     | Usable Hosts | Notes                    | IP Range                |
|-----------------|-----------------|--------------|--------------------------|-------------------------|
| 10.1.100.0/29   | 255.255.255.248 | 6            | BH routers to mls right  | 10.1.100.0 – 10.1.100.7 |
| 10.1.100.8/29   | 255.255.255.248 | 6            | BH routers to mls left   | 10.1.100.8 – 10.1.100.15|
|-----------------|-----------------|--------------|--------------------------|-------------------------|
| 10.2.100.0/29   | 255.255.255.248 | 6            | SA routers to mls right  | 10.2.100.0 – 10.2.100.7 |
| 10.2.100.8/29   | 255.255.255.248 | 6            | SA routers to mls left   | 10.2.100.8 – 10.2.100.15|
|-----------------|-----------------|--------------|--------------------------|-------------------------|
| 10.3.100.0/29   | 255.255.255.248 | 6            | KW routers to mls right  | 10.3.100.0 – 10.3.100.7 |
| 10.3.100.8/29   | 255.255.255.248 | 6            | KW routers to mls left   | 10.3.100.8 – 10.3.100.15|










### Public IP Scheme for Bahrain Islamic Bank (BisB) Network

The company has been assigned the public IP range **192.124.249.32/27**, which provides 32 IP addresses (192.124.249.32 - 192.124.249.63). The usable host addresses are 192.124.249.33 to 192.124.249.62. This range is allocated for WAN links across three sites (Bahrain, Kuwait, and Saudi Arabia) and for static NAT for the HQ server in Bahrain.

#### Public IP Allocation Table

| **Purpose**                | **Subnet**         | **Usable IPs**          | **Assignments**                                      |
|----------------------------|--------------------|-------------------------|------------------------------------------------------|
| Bahrain Active WAN Link    | 192.124.249.32/30 | 192.124.249.33 - 34    | ISP: 192.124.249.33, bh-m-active-router: 192.124.249.34 |
| Bahrain Standby WAN Link   | 192.124.249.36/30 | 192.124.249.37 - 38    | ISP: 192.124.249.37, bh-m-standby-router: 192.124.249.38 |
| Kuwait Active WAN Link     | 192.124.249.40/30 | 192.124.249.41 - 42    | ISP: 192.124.249.41, kw-k-active-router: 192.124.249.42 |
| Kuwait Standby WAN Link    | 192.124.249.44/30 | 192.124.249.45 - 46    | ISP: 192.124.249.45, kw-k-standby-router: 192.124.249.46 |
| Saudi Active WAN Link      | 192.124.249.48/30 | 192.124.249.49 - 50    | ISP: 192.124.249.49, sa-r-active-router: 192.124.249.50 |
| Saudi Standby WAN Link     | 192.124.249.52/30 | 192.124.249.53 - 54    | ISP: 192.124.249.53, sa-r-standby-router: 192.124.249.54 |
| HQ Server (Web/Email)      | N/A                | 192.124.249.56         | Static NAT for server (10.1.9.4)                     |
| Remaining Usable IPs       | N/A                | 192.124.249.57 - 62    | Available for future use                             |
| Network Address            | 192.124.249.32    | N/A                     | Reserved                                             |
| Broadcast Address          | 192.124.249.63    | N/A                     | Reserved                                             |

#### Notes
- **WAN Links**: Each WAN link uses a /30 subnet, providing two usable IP addresses: one for the ISP and one for the router’s WAN interface.
- **HQ Server**: The server uses static NAT with port-specific mappings for HTTP (80), HTTPS (443), and SMTP (25) to the public IP 192.124.249.56.
- **Remaining IPs**: Six usable IPs (192.124.249.57 - 192.124.249.62) are available for future expansion, such as additional servers or services.
